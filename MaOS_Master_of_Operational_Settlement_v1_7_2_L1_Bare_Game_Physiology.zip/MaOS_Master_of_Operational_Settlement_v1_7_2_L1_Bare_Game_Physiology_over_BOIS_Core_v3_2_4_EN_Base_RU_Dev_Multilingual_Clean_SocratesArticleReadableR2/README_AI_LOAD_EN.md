# MaOS - Master of Operational Settlement | L1 bare game physiology archive

Version: v1.7.2-bare-game-physiology-core3.2.4-enbase-rudev-i18n-clean  
Build UTC: 2026-06-23T04:53:29Z  
Base BOIS core: v3.2.4-sokrat-bare-enbase-rudev

This is a clean English-base / Russian-development-canonical MaOS L1 BOIS-game archive. It contains the active game physiology over the BOIS Core dependency, public multilingual locale packs, content-safety profiles, safe deterministic seed export/import, and the in-game author support display rule.

## Load order

1. Verify `integrity/hashes.sha256` from the archive root.
2. Load `BOOTSTRAP_MAOS_L1_CANONICAL_EN.pdf` first. It is the canonical boot PDF for this English-base build.
3. Read `language_policy.json` and choose the operator/public locale.
4. Load `core/maos.machine.json` as the active game machine map.
5. Load the current BOIS dependency from `base/bois_core/`, starting with `base/bois_core/BOOTSTRAP_BARE_PHYSIOLOGY_CANONICAL_EN.pdf`.
6. Load runtime modules, state schemas, surface templates, tables and the selected language folder.
7. For ordinary public play, use `release/player/` or the matching `languages/<code>/public/` files.
8. Do not create first scene, procedural seed, GM-state capsule, visible state or character personal machines before the full master card.

## Clean archive boundary

This package intentionally excludes prior-build notes, migration notes, proposal notes, packaged scenario-run traces, balance-run logs, developer report packages and human-playtest placeholder packages. It keeps only current active physiology and current integrity metadata.

## Validation boundary

Static structure, JSON/CSV parsing, reference checks, hash checks and PDF render smoke checks were performed. QA-E human playtest is not claimed.

## Safety boundary

MaOS is a fictional text game and not real-world survival, engineering, medical, legal, logistics, safety or crisis-management advice.

# Author support message

If you enjoyed BOIS and MaOS and would like to support the project, you can subscribe on Patreon or make a one-time donation through Ko-fi or Buy Me a Coffee.

[Support on Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[One-time donation on Ko-fi](https://ko-fi.com/temnik)  
[One-time donation on Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Thank you for your support. It helps me keep working on the next levels.
