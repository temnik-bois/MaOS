Авторское сообщение поддержки

Если вам понравились BOIS и MaOS и вы хотите поддержать развитие проекта, вы можете подписаться на Patreon или сделать разовое пожертвование через Ko-fi или Buy Me a Coffee.

[Поддержать на Patreon](https://www.patreon.com/cw/MaOS_aigame)
[Разовое пожертвование на Ko-fi](https://ko-fi.com/temnik)
[Разовое пожертвование на Buy Me a Coffee](https://buymeacoffee.com/temnik)
[About me](www.temnik.com)

Спасибо за поддержку. Она помогает мне продолжать работу над следующими уровнями.
