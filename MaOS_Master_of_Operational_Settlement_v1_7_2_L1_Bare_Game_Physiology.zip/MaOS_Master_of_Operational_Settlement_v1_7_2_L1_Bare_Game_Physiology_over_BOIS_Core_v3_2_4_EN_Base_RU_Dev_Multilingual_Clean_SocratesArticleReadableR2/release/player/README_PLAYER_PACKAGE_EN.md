# MaOS L1 public player package

Use this folder for broad multilingual distribution. Start with the language quickstart and the master-card template.

Recommended first file: `languages/en/QUICKSTART_PLAYER_EN.md`, or the matching locale folder.

The full archive boot PDF remains `../../BOOTSTRAP_MAOS_L1_CANONICAL_EN.pdf`.

## Clean boundary

The player package contains current player-facing game physiology only. It does not include prior-build notes, packaged scenario-run traces, balance-run logs, hidden L1 details, GM-state, future events, exact balance weights, developer report packages, or human-playtest placeholders.

## Author support visibility

The player package includes the author support message for every public locale. During play, the message must be shown as a non-diegetic footer in the first Startup Gate greeting, and may be shown again on `support`, `credits`, `about`, `donate`, or `author`. It never spends a shift, changes state, affects balance, reveals hidden L1, or gates access to play.
