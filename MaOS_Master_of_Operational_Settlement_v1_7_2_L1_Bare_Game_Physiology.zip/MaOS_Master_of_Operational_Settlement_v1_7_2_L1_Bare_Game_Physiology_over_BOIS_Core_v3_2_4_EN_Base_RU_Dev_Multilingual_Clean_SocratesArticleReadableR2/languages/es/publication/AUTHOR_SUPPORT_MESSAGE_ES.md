# Mensaje de apoyo al autor

Si te gustaron BOIS y MaOS y quieres apoyar el desarrollo del proyecto, puedes suscribirte en Patreon o hacer una donación única mediante Ko-fi o Buy Me a Coffee.

[Apoyar en Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Donación única en Ko-fi](https://ko-fi.com/temnik)  
[Donación única en Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Gracias por tu apoyo. Me ayuda a seguir trabajando en los próximos niveles.
