# MaOS - Maestro del Asentamiento Operativo - Quickstart

Un juego textual BOIS sobre construir un asentamiento operativo estable con conocimiento incompleto.

## 1. What this is
MaOS es un juego ficticio en chat con IA. Eres el maestro del asentamiento: decides prioridades, aceptas costes, proteges a las personas y aprendes de los rebotes.

## 2. Safety boundary
No es una guía real de supervivencia, ingeniería, medicina, derecho, logística ni gestión de crisis.

## 3. Start
Send: `Iniciar MaOS`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# Ficha del maestro

- master_name: Nombre del maestro del asentamiento
- grammatical_address: Cómo debe dirigirse a ti el juego
- working_style: Estilo de trabajo o gobierno
- main_priority: Prioridad principal
- forbidden_boundary: Límite prohibido o condición de parada
- aide_name: Nombre del asesor de IA
- advice_style: Estilo del asesor
- visible_complexity: Complejidad visible: compacta, normal o detallada
- content_safety_profile (optional): Perfil de seguridad de contenido: family_safe, standard_public o tense_clean

Start command: `Iniciar MaOS`


## 5. Play loop
Escribe acciones en lenguaje libre. Normalmente se ejecuta una acción principal por turno. Las órdenes demasiado amplias se aclaran o se degradan antes de gastar estado.

## 6. Advisor boundary
El asesor compara riesgos visibles e incógnitas. No conoce el L1 oculto, no revela el mejor movimiento y no da una guía paso a paso.

## 7. Save and seed
Pide un paquete de guardado para conservar estado visible, referencia pública de seed, deudas abiertas e información de reversión.

La exportación/importación de seed es determinista para pruebas y traducciones, pero nunca exporta umbrales L1 ocultos, eventos futuros ni GM-state.

## 8. Límite del archivo limpio
Este paquete contiene solo la fisiología activa actual del juego. Las notas de versiones anteriores, las trazas de escenarios, los registros de equilibrio y los marcadores de playtest humano no forman parte del archivo para jugadores. No se afirma QA-E humano.

---

# Mensaje de apoyo del autor

Si disfrutaste BOIS y MaOS y quieres apoyar el proyecto, puedes suscribirte en Patreon o hacer una donación única por Ko-fi o Buy Me a Coffee.

[Apoyar en Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Donación única en Ko-fi](https://ko-fi.com/temnik)  
[Donación única en Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Gracias por tu apoyo. Me ayuda a seguir trabajando en los siguientes niveles.

## Mensaje de apoyo al autor visibility

El juego muestra este mensaje de apoyo al autor como un pie no diegético en el primer saludo de inicio, y después solo a petición de support / credits / about / donate o en superficies de publicación/archivo.

Está fuera de la ficción: no gasta turno, no cambia estado, no revela L1 oculto, no cambia el balance y no bloquea el acceso al juego.

Puedes escribir support, credits, about o donate para volver a mostrar este mensaje sin gastar un turno.
