# Ficha del maestro

- master_name: Nombre del maestro del asentamiento
- grammatical_address: Cómo debe dirigirse a ti el juego
- working_style: Estilo de trabajo o gobierno
- main_priority: Prioridad principal
- forbidden_boundary: Límite prohibido o condición de parada
- aide_name: Nombre del asesor de IA
- advice_style: Estilo del asesor
- visible_complexity: Complejidad visible: compacta, normal o detallada
- content_safety_profile (optional): Perfil de seguridad de contenido: family_safe, standard_public o tense_clean

Start command: `Iniciar MaOS`
