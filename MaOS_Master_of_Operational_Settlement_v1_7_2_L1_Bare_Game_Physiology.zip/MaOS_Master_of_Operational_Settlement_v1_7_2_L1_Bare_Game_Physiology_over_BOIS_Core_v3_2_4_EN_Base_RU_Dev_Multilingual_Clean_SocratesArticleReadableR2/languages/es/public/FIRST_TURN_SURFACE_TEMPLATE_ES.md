# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
El asesor compara riesgos visibles e incógnitas. No conoce el L1 oculto, no revela el mejor movimiento y no da una guía paso a paso.

## Content-safety profile
Perfil de seguridad de contenido: family_safe, standard_public o tense_clean
