# 作者支持信息

如果你喜欢 BOIS 和 MaOS，并想支持项目发展，可以在 Patreon 订阅，或通过 Ko-fi / Buy Me a Coffee 进行一次性捐助。

[在 Patreon 支持](https://www.patreon.com/cw/MaOS_aigame)  
[在 Ko-fi 一次性捐助](https://ko-fi.com/temnik)  
[在 Buy Me a Coffee 一次性捐助](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

感谢你的支持。它帮助我继续开发后续关卡。
