# 主控卡

- master_name: 聚落之主姓名
- grammatical_address: 游戏应如何称呼你
- working_style: 工作或治理风格
- main_priority: 主要优先级
- forbidden_boundary: 禁止边界或停止条件
- aide_name: AI 顾问姓名
- advice_style: 顾问风格
- visible_complexity: 可见复杂度：compact、normal 或 detailed
- content_safety_profile (optional): 内容安全配置：family_safe、standard_public 或 tense_clean

Start command: `开始 MaOS`
