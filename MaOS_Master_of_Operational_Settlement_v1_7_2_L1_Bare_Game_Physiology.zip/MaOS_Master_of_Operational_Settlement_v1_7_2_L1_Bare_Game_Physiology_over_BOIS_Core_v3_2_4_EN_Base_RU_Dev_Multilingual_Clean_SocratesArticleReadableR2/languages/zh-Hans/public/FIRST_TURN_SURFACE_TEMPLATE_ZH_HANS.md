# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
顾问只比较可见风险和未知。它不知道隐藏 L1，不透露最佳行动，也不提供通关攻略。

## Content-safety profile
内容安全配置：family_safe、standard_public 或 tense_clean
