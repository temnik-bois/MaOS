# MaOS - 运营聚落之主 - Quickstart

一款关于在不完全知识下建立稳定运营聚落的文本 BOIS 游戏。

## 1. What this is
MaOS 是一款虚构的 AI 聊天游戏。你是聚落之主：决定优先级，接受代价，保护人，并从反弹中学习。

## 2. Safety boundary
这不是现实中的生存、工程、医疗、法律、物流或危机管理建议。

## 3. Start
Send: `开始 MaOS`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# 主控卡

- master_name: 聚落之主姓名
- grammatical_address: 游戏应如何称呼你
- working_style: 工作或治理风格
- main_priority: 主要优先级
- forbidden_boundary: 禁止边界或停止条件
- aide_name: AI 顾问姓名
- advice_style: 顾问风格
- visible_complexity: 可见复杂度：compact、normal 或 detailed
- content_safety_profile (optional): 内容安全配置：family_safe、standard_public 或 tense_clean

Start command: `开始 MaOS`


## 5. Play loop
用自然语言写行动。通常每个班次执行一个主要行动。过宽的命令会在消耗状态前被澄清或降级。

## 6. Advisor boundary
顾问只比较可见风险和未知。它不知道隐藏 L1，不透露最佳行动，也不提供通关攻略。

## 7. Save and seed
请求保存包可保留可见状态、公开 seed 引用、未清债务和回滚信息。

seed 导出/导入可用于测试和翻译的确定性复现，但绝不导出隐藏 L1 阈值、未来事件或 GM-state。

## 8. 干净归档边界
本包只包含当前有效的游戏生理。旧构建说明、场景运行痕迹、平衡运行日志和人工 playtest 占位材料不属于面向玩家的归档。不声明已完成人工 QA-E playtest。

---

# 作者支持信息

如果你喜欢 BOIS 和 MaOS，并想支持项目发展，可以在 Patreon 订阅，或通过 Ko-fi / Buy Me a Coffee 一次性捐助。

[在 Patreon 支持](https://www.patreon.com/cw/MaOS_aigame)  
[在 Ko-fi 一次性捐助](https://ko-fi.com/temnik)  
[在 Buy Me a Coffee 一次性捐助](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

感谢你的支持。它帮助我继续开发下一层级。

## 作者支持信息 visibility

游戏会在第一次启动问候中以非叙事页脚显示这条作者支持信息；之后只在 support / credits / about / donate 请求，或发布/归档界面中显示。

它位于剧情之外：不消耗班次，不改变状态，不透露隐藏 L1，不改变平衡，也不会限制玩家进入游戏。

你可以输入 support、credits、about 或 donate，在不消耗班次的情况下再次显示这条信息。
