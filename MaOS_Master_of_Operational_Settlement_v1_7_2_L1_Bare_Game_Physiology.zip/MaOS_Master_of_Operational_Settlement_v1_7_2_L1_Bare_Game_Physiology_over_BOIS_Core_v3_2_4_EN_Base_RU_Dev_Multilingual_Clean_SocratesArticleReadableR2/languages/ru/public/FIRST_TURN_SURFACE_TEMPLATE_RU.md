# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
Советник сравнивает видимые риски и неизвестные. Он не знает скрытый L1, не раскрывает лучший ход и не даёт готовое прохождение.

## Content-safety profile
Профиль безопасности контента: family_safe [семейный], standard_public [публичный стандарт] или tense_clean [напряжённый без натурализма]
