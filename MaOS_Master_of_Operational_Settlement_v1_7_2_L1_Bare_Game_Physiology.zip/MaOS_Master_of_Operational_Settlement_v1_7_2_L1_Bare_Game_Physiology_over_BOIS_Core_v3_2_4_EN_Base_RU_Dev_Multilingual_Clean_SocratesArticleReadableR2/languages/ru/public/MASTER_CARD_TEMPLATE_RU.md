# Карточка мастера

- master_name: Имя мастера поселения
- grammatical_address: Как игра должна к вам обращаться
- working_style: Рабочий стиль / стиль управления
- main_priority: Главный приоритет
- forbidden_boundary: Запретная граница или стоп-условие
- aide_name: Имя ИИ-консультанта
- advice_style: Стиль советов консультанта
- visible_complexity: Сложность видимой поверхности: компактная, обычная или подробная
- content_safety_profile (optional): Профиль безопасности контента: family_safe [семейный], standard_public [публичный стандарт] или tense_clean [напряжённый без натурализма]

Start command: `Начать MaOS`
