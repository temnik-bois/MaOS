# 저자 후원 메시지

BOIS와 MaOS가 마음에 들었고 프로젝트 개발을 후원하고 싶다면 Patreon을 구독하거나 Ko-fi 또는 Buy Me a Coffee로 일회성 후원을 할 수 있습니다.

[Patreon에서 후원](https://www.patreon.com/cw/MaOS_aigame)  
[Ko-fi 일회성 후원](https://ko-fi.com/temnik)  
[Buy Me a Coffee 일회성 후원](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

후원해 주셔서 감사합니다. 다음 레벨 작업을 계속하는 데 도움이 됩니다.
