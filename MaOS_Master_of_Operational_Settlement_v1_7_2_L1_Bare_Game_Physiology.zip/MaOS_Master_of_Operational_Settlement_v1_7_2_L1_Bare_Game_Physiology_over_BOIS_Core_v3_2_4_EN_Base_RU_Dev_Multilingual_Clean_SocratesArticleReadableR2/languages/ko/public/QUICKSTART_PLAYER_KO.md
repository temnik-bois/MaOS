# MaOS - 운영 정착지의 마스터 - Quickstart

불완전한 지식 속에서 안정적인 운영 정착지를 만드는 텍스트 BOIS 게임입니다.

## 1. What this is
MaOS는 AI 채팅에서 진행되는 허구의 게임입니다. 당신은 정착지의 마스터로서 우선순위를 정하고, 비용을 받아들이며, 사람을 보호하고, 반동에서 배웁니다.

## 2. Safety boundary
이것은 실제 생존, 공학, 의료, 법률, 물류 또는 위기관리 조언이 아닙니다.

## 3. Start
Send: `MaOS 시작`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# 마스터 카드

- master_name: 정착지 마스터 이름
- grammatical_address: 게임이 당신을 부르는 방식
- working_style: 작업 또는 거버넌스 스타일
- main_priority: 주요 우선순위
- forbidden_boundary: 금지 경계 또는 중지 조건
- aide_name: AI 조언자 이름
- advice_style: 조언 스타일
- visible_complexity: 표시 복잡도: compact, normal, detailed
- content_safety_profile (optional): 콘텐츠 안전 프로필: family_safe, standard_public, tense_clean

Start command: `MaOS 시작`


## 5. Play loop
자유 문장으로 행동을 입력합니다. 보통 한 교대에는 하나의 주요 행동만 실행됩니다. 너무 넓은 명령은 상태를 쓰기 전에 확인되거나 축소됩니다.

## 6. Advisor boundary
조언자는 보이는 위험과 미지수를 비교합니다. 숨겨진 L1을 모르며, 최선의 수를 공개하지 않고, 공략을 제공하지 않습니다.

## 7. Save and seed
저장 패키지를 요청하면 보이는 상태, 공개 seed 참조, 열린 부채, 롤백 정보를 보존합니다.

seed 내보내기/가져오기는 테스트와 번역을 위해 결정적이지만 숨겨진 L1 임계값, 미래 이벤트, GM-state는 내보내지 않습니다.

## 8. 클린 아카이브 경계
이 패키지에는 현재 활성 게임 생리만 포함됩니다. 이전 빌드 노트, 시나리오 실행 흔적, 밸런스 실행 로그, 인간 플레이테스트 자리표시는 플레이어용 아카이브에 포함되지 않습니다. 인간 QA-E 플레이테스트는 주장하지 않습니다.

---

# 저자 지원 메시지

BOIS와 MaOS가 마음에 들고 프로젝트를 지원하고 싶다면 Patreon을 구독하거나 Ko-fi 또는 Buy Me a Coffee로 일회성 후원을 할 수 있습니다.

[Patreon에서 지원](https://www.patreon.com/cw/MaOS_aigame)  
[Ko-fi 일회성 후원](https://ko-fi.com/temnik)  
[Buy Me a Coffee 일회성 후원](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

지원해 주셔서 감사합니다. 다음 레벨 작업을 계속하는 데 도움이 됩니다.

## 저자 후원 메시지 visibility

게임은 이 저자 후원 메시지를 첫 시작 인사에서 비서사적 푸터로 표시하며, 이후에는 support / credits / about / donate 요청 또는 릴리스/아카이브 표면에서만 표시합니다.

이 메시지는 픽션 밖에 있습니다. 교대를 소비하지 않고, 상태를 바꾸지 않고, 숨겨진 L1을 공개하지 않고, 밸런스를 바꾸지 않으며, 플레이 접근을 막지 않습니다.

support, credits, about, donate를 입력하면 교대를 쓰지 않고 이 메시지를 다시 볼 수 있습니다.
