# 마스터 카드

- master_name: 정착지 마스터 이름
- grammatical_address: 게임이 당신을 부르는 방식
- working_style: 작업 또는 거버넌스 스타일
- main_priority: 주요 우선순위
- forbidden_boundary: 금지 경계 또는 중지 조건
- aide_name: AI 조언자 이름
- advice_style: 조언 스타일
- visible_complexity: 표시 복잡도: compact, normal, detailed
- content_safety_profile (optional): 콘텐츠 안전 프로필: family_safe, standard_public, tense_clean

Start command: `MaOS 시작`
