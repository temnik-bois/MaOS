# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
조언자는 보이는 위험과 미지수를 비교합니다. 숨겨진 L1을 모르며, 최선의 수를 공개하지 않고, 공략을 제공하지 않습니다.

## Content-safety profile
콘텐츠 안전 프로필: family_safe, standard_public, tense_clean
