# Unterstützungsnachricht des Autors

Wenn dir BOIS und MaOS gefallen haben und du die Entwicklung des Projekts unterstützen möchtest, kannst du Patreon abonnieren oder eine einmalige Spende über Ko-fi oder Buy Me a Coffee machen.

[Auf Patreon unterstützen](https://www.patreon.com/cw/MaOS_aigame)  
[Einmalige Spende auf Ko-fi](https://ko-fi.com/temnik)  
[Einmalige Spende auf Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Danke für deine Unterstützung. Sie hilft mir, weiter an den nächsten Leveln zu arbeiten.
