# Meisterkarte

- master_name: Name der Siedlungsleitung
- grammatical_address: Wie das Spiel dich ansprechen soll
- working_style: Arbeits- oder Führungsstil
- main_priority: Hauptpriorität
- forbidden_boundary: Verbotene Grenze oder Stoppbedingung
- aide_name: Name des KI-Beraters
- advice_style: Beratungsstil
- visible_complexity: Sichtbare Komplexität: kompakt, normal oder detailliert
- content_safety_profile (optional): Inhaltssicherheitsprofil: family_safe, standard_public oder tense_clean

Start command: `MaOS starten`
