# MaOS - Meister der operativen Siedlung - Quickstart

Ein textbasiertes BOIS-Spiel über den Aufbau einer stabilen operativen Siedlung unter unvollständigem Wissen.

## 1. What this is
MaOS ist ein fiktives KI-Chat-Spiel. Du bist die Siedlungsleitung: du setzt Prioritäten, akzeptierst Kosten, schützt Menschen und lernst aus Rückkopplungen.

## 2. Safety boundary
Dies ist keine reale Anleitung für Überleben, Technik, Medizin, Recht, Logistik oder Krisenmanagement.

## 3. Start
Send: `MaOS starten`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# Meisterkarte

- master_name: Name der Siedlungsleitung
- grammatical_address: Wie das Spiel dich ansprechen soll
- working_style: Arbeits- oder Führungsstil
- main_priority: Hauptpriorität
- forbidden_boundary: Verbotene Grenze oder Stoppbedingung
- aide_name: Name des KI-Beraters
- advice_style: Beratungsstil
- visible_complexity: Sichtbare Komplexität: kompakt, normal oder detailliert
- content_safety_profile (optional): Inhaltssicherheitsprofil: family_safe, standard_public oder tense_clean

Start command: `MaOS starten`


## 5. Play loop
Schreibe freie Handlungen. Normalerweise wird pro Schicht eine Hauptaktion ausgeführt. Zu breite Befehle werden geklärt oder abgeschwächt, bevor Zustand verbraucht wird.

## 6. Advisor boundary
Der Berater vergleicht sichtbare Risiken und Unbekannte. Er kennt L1 nicht, verrät keinen besten Zug und liefert keinen Walkthrough.

## 7. Save and seed
Fordere ein Speicherpaket an, um sichtbaren Zustand, öffentliche Seed-Referenz, offene Schulden und Rollback-Information zu sichern.

Seed-Export/Import ist für Tests und Übersetzungen deterministisch, exportiert aber nie versteckte L1-Schwellen, zukünftige Ereignisse oder GM-State.

## 8. Grenze des sauberen Archivs
Dieses Paket enthält nur die aktuelle aktive Spielphysiologie. Frühere Build-Notizen, Szenario-Spuren, Balance-Läufe und Platzhalter für menschliche Playtests gehören nicht zum spielerseitigen Archiv. Menschliches QA-E-Playtesting wird nicht beansprucht.

---

# Unterstützungsnachricht des Autors

Wenn dir BOIS und MaOS gefallen haben und du das Projekt unterstützen möchtest, kannst du Patreon abonnieren oder einmalig über Ko-fi oder Buy Me a Coffee spenden.

[Auf Patreon unterstützen](https://www.patreon.com/cw/MaOS_aigame)  
[Einmalige Spende auf Ko-fi](https://ko-fi.com/temnik)  
[Einmalige Spende auf Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Danke für deine Unterstützung. Sie hilft mir, an den nächsten Ebenen weiterzuarbeiten.

## Unterstützungsnachricht des Autors visibility

Das Spiel zeigt diese Unterstützungsnachricht des Autors als nicht-diegetischen Footer bei der ersten Startbegrüßung und danach nur auf support / credits / about / donate oder in Release-/Archivflächen.

Sie liegt außerhalb der Fiktion: Sie verbraucht keine Schicht, ändert keinen Zustand, enthüllt kein verborgenes L1, ändert kein Balancing und sperrt keinen Spielzugang.

Du kannst support, credits, about oder donate schreiben, um diese Nachricht erneut ohne Schichtverbrauch anzuzeigen.
