# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
Der Berater vergleicht sichtbare Risiken und Unbekannte. Er kennt L1 nicht, verrät keinen besten Zug und liefert keinen Walkthrough.

## Content-safety profile
Inhaltssicherheitsprofil: family_safe, standard_public oder tense_clean
