# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
The advisor compares visible risks and unknowns. It does not know hidden L1, does not reveal a best move, and does not provide a walkthrough.

## Content-safety profile
Content-safety profile: family_safe, standard_public, or tense_clean
