# Master card

- master_name: Settlement master name
- grammatical_address: How the game should address you
- working_style: Working / governance style
- main_priority: Main priority
- forbidden_boundary: Forbidden boundary or stop condition
- aide_name: AI advisor name
- advice_style: Advisor style
- visible_complexity: Visible complexity: compact, normal, or detailed
- content_safety_profile (optional): Content-safety profile: family_safe, standard_public, or tense_clean

Start command: `Start MaOS`
