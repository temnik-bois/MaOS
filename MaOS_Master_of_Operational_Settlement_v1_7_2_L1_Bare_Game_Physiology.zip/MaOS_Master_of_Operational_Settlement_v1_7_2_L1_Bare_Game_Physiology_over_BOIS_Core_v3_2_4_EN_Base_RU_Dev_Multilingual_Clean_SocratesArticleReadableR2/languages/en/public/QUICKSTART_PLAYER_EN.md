# MaOS - Master of Operational Settlement - Quickstart

A text BOIS game about building a stable operational settlement under incomplete knowledge.

## 1. What this is
MaOS is a fictional AI-chat game. You are the Settlement Master. You decide priorities, accept costs, preserve people, and learn from rebounds.

## 2. Safety boundary
This is not real survival, engineering, medical, legal, logistics, or crisis-management advice.

## 3. Start
Send: `Start MaOS`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# Master card

- master_name: Settlement master name
- grammatical_address: How the game should address you
- working_style: Working / governance style
- main_priority: Main priority
- forbidden_boundary: Forbidden boundary or stop condition
- aide_name: AI advisor name
- advice_style: Advisor style
- visible_complexity: Visible complexity: compact, normal, or detailed
- content_safety_profile (optional): Content-safety profile: family_safe, standard_public, or tense_clean

Start command: `Start MaOS`


## 5. Play loop
Write free-form actions. Normally one primary action can be executed per shift. Broad commands are clarified or degraded before state is spent.

## 6. Advisor boundary
The advisor compares visible risks and unknowns. It does not know hidden L1, does not reveal a best move, and does not provide a walkthrough.

## 7. Save and seed
Ask for a save package to preserve visible state, public seed reference, open debts, and rollback information.

Seed export/import is deterministic for testing and translations, but it never exports hidden L1 thresholds, future events, or GM-state.

## 8. Clean archive boundary
This package contains the current active game physiology only. Prior-build notes, packaged scenario-run traces, balance-run logs and human-playtest placeholders are not part of the player-facing archive. Human QA-E playtest is not claimed.

---

# Author support message

If you enjoyed BOIS and MaOS and would like to support the project, you can subscribe on Patreon or make a one-time donation through Ko-fi or Buy Me a Coffee.

[Support on Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[One-time donation on Ko-fi](https://ko-fi.com/temnik)  
[One-time donation on Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Thank you for your support. It helps me keep working on the next levels.

## Author support message visibility

The game shows this author support message as a non-diegetic footer at the first startup greeting, and again only on support / credits / about / donate request or in release/archive surfaces.

It is outside the fiction: it does not spend a shift, change state, reveal hidden L1, change balance, or gate access to play.

You can type support, credits, about, or donate to show this message again without spending a shift.
