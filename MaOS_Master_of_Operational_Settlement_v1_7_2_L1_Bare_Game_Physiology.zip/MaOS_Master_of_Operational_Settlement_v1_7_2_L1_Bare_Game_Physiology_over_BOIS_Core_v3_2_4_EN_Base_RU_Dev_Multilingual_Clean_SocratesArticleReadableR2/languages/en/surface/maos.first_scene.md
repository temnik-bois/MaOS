# First MaOS scene

Day 3. Morning. Plateau K-17.

Dust stands beyond the dome edge like a low wall. The northern seam has again left a wet line on the inner membrane. There are enough filters if the old pump is not touched, but that pump is what keeps the water reserve alive until the Center's next run. Two technicians argue: one wants to seal the seam before the front arrives; the other fears losing the chance to inspect the dry channel before visibility worsens.

State: water 43; food 31; filters 8 working / 2 dirty; sealant 4; parts 9; energy +18%; crew 37; fatigue 22; dome: northern seam leak.

Risk clocks:
1. Water is green, but depends on the pump.
2. Fatigue is below the error threshold, but close to rising.
3. The weather window for outside work closes in 5-7 hours.

Shift budget: normally one primary action per shift. Bundled actions are allowed only through explicit quality degradation, secondary actions, protocols or governance modes.

Operational actions:
A. Seal the northern seam first.
B. Send a small group to the dry channel.
C. Stop the old pump and preserve filters.
D. Rest the technicians and redistribute shifts.

Advisory action:
E. Ask the AI advisor to assess risks, alternatives and unknowns. This does not spend a shift unless the council is dragged out.

You may also write a free command; broad commands will be parsed through the shift budget.
