# Failure postmortem without walkthrough

Purpose: close the party honestly, show the local causal chain of failure and preserve learning value without revealing how to win.

Allowed to show:
- visible ending type: collapse, evacuation, emergency shutdown or partial failure;
- only actions, signs, events and debts already visible to the player in this party;
- a short chain: decision -> neglected debt -> rebound -> unrepaired procedure -> ending;
- 1-3 reflection questions about causality without naming the correct action.

Forbidden to show:
- the correct move or move order;
- a phrase like "you should have done X";
- a specific alternative that would have saved the party;
- hidden numerical thresholds, GM-state, seed, L1 criteria, hidden victory moment or future major events;
- full personal machines of characters;
- reusable walkthrough.

Template:
Party ending: ...
Local causal chain: ...
What was visible before failure: ...
Which debt stayed without an owner or method: ...
Question without hint: "Which class of debt kept repeating in this party?"

Forbidden phrase: this postmortem does not state which action was correct or how to pass the next party.
