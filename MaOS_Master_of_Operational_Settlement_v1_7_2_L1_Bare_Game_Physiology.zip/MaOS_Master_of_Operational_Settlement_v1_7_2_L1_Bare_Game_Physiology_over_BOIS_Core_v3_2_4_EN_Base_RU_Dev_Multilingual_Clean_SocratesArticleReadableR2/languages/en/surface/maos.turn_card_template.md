# MaOS turn card

The output form follows visible surface complexity from the master card: compact / normal / detailed. Complexity changes text volume, but not state commit, balance or hidden causality.

Scene: 4-6 lines in normal surface; fewer in compact, more in detailed.

State: main visible fields + risk clocks.

Shift budget:
- Normally one primary action.
- Secondary actions are allowed only with a separate owner and cost.
- A governance mode is not physical work.
- Non-executed parts of a bundle are recorded as why-not-done.

Tensions:
1. ...
2. ...
3. ...

Consequence of previous turn: one line.

Delta ledger: for an operational shift, show before / delta / after / why for key changes.

Operational actions:
A. ...
B. ...
C. ...
D. ...

Advisory action:
E. Ask the AI advisor to assess risks, alternatives and unknowns. It does not spend a shift unless the council is dragged out.

Free command is allowed, but broad bundles pass through the shift budget.
