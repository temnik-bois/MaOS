# State delta ledger

Shown after every closed operational shift.

| Field | Before | Delta | After | Visible reason | Owner |
|---|---:|---:|---:|---|---|
| Water | ... | ... | ... | ... | MAOS-RESOURCES |
| Fatigue | ... | ... | ... | ... | MAOS-CREW-STATE |
| Trust | ... | ... | ... | ... | MAOS-CREW-STATE |
| Asset/debt | ... | ... | ... | ... | MAOS-STATE |

Forbidden: hidden L1, seed, GM-state, exact hidden weights.
