The archive has been analyzed in isolation. Integrity control passed when `integrity/hashes.sha256` verifies. Active contour accepted: MaOS L1 v1.7.2-bare-game-physiology-core3.2.4-enbase-rudev-i18n-clean. Information from other windows is not used.

## MaOS launched: Startup Gate

The first scene is not open yet. The shift has not started; procedural seed, GM-state capsule, character registry and personal machines have not been created.

First, fill the master card. It sets the value filter, surface style and decision boundaries; it is not a hidden victory route.

## Master card

1. Settlement master name:
2. How to address you: informal / formal / other
3. Governance style: methodical / strict / consultative / cautious / crew autonomy / mixed
4. Main priority: people / resources / dome / scouting / balance / autonomy / other
5. Forbidden boundary: for example, do not treat people as expendable; do not trust the Center without facts; do not risk the dome for a hypothesis; do not hide the cost of decisions.
6. AI advisor name:
7. Advisor style: brief / risk-focused / alternatives-focused / detailed / Socratic
8. Visible surface complexity: compact / normal / detailed

Short format:

```text
Master: <name>.
Address: informal.
Style: methodical.
Priority: balance.
Boundary: do not treat people as expendable.
AI: <advisor name>.
Advice: detailed, with risks.
Surface: detailed.
```

After the card, the starting party, hidden state, visible state, key-people registry and first scene are created.

Rules in this build: one primary action per shift unless quality degradation is explicitly accepted; multi-action orders pass through the shift budget; the advisor does not know hidden L1 and does not provide a walkthrough; the Center is not treated as proof of rescue without confirmation; after a turn, show executed and non-executed parts, delta ledger, assets and open debts.

## Author support message

If you enjoyed BOIS and MaOS and would like to support the project, you can subscribe on Patreon or make a one-time donation through Ko-fi or Buy Me a Coffee.

[Support on Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[One-time donation on Ko-fi](https://ko-fi.com/temnik)  
[One-time donation on Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Thank you for your support. It helps me keep working on the next levels.

_This footer is outside the fiction. It does not spend a shift, change state, reveal hidden L1, change balance, or gate access to play._
