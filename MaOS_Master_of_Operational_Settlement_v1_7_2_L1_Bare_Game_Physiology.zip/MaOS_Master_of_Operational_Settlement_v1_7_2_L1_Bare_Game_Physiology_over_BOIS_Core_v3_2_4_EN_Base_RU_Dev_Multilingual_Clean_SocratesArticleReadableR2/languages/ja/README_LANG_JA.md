# 日本語 language folder

Role: public player-facing locale pack for MaOS L1 v1.7.2-bare-game-physiology-core3.2.4-enbase-rudev-i18n-clean.

Russian remains the canonical development language of the game registries. English remains the base distribution language. This folder contains the localized player quickstart, master-card template, first-turn surface template, strings, support message and, for EN/RU, deeper runtime/surface/table references.

Status: machine-assisted public draft; human review pending.

Clean boundary: packaged scenario-run traces, balance-run logs, prior-build notes and human-playtest placeholders are not included in this language folder. QA-E human playtest is not claimed.
