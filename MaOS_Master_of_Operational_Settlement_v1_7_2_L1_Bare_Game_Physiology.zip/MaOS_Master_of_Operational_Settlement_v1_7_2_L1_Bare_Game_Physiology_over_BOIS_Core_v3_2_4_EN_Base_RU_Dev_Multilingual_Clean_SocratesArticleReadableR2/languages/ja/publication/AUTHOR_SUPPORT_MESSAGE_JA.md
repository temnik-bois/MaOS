# 作者支援メッセージ

BOIS と MaOS を気に入ってプロジェクトの発展を支援したい場合は、Patreon で購読するか、Ko-fi または Buy Me a Coffee で一回限りの寄付ができます。

[Patreon で支援](https://www.patreon.com/cw/MaOS_aigame)  
[Ko-fi で一回限りの寄付](https://ko-fi.com/temnik)  
[Buy Me a Coffee で一回限りの寄付](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

ご支援ありがとうございます。次のレベルの開発を続ける助けになります。
