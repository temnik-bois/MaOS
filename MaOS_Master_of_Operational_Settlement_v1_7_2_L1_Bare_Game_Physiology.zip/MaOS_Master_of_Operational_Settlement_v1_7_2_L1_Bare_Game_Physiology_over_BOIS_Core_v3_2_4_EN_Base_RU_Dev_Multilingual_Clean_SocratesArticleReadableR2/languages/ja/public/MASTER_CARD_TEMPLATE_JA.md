# マスターカード

- master_name: 居住地マスターの名前
- grammatical_address: ゲームがあなたをどう呼ぶか
- working_style: 作業または統治スタイル
- main_priority: 主な優先事項
- forbidden_boundary: 禁止境界または停止条件
- aide_name: AI助言者の名前
- advice_style: 助言スタイル
- visible_complexity: 表示の複雑さ: compact, normal, detailed
- content_safety_profile (optional): コンテンツ安全プロファイル: family_safe, standard_public, tense_clean

Start command: `MaOSを開始`
