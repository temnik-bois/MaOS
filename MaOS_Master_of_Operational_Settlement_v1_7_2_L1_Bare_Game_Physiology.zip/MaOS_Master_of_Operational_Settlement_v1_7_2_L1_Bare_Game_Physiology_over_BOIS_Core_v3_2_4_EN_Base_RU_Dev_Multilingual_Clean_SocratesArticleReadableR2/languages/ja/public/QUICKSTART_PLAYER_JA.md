# MaOS - 運用居住地のマスター - Quickstart

不完全な知識のもとで安定した運用居住地を作るテキスト型BOISゲームです。

## 1. What this is
MaOSはAIチャットで遊ぶ架空のゲームです。あなたは居住地のマスターとして、優先順位を決め、コストを受け止め、人を守り、反動から学びます。

## 2. Safety boundary
これは現実のサバイバル、工学、医療、法律、物流、危機管理の助言ではありません。

## 3. Start
Send: `MaOSを開始`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# マスターカード

- master_name: 居住地マスターの名前
- grammatical_address: ゲームがあなたをどう呼ぶか
- working_style: 作業または統治スタイル
- main_priority: 主な優先事項
- forbidden_boundary: 禁止境界または停止条件
- aide_name: AI助言者の名前
- advice_style: 助言スタイル
- visible_complexity: 表示の複雑さ: compact, normal, detailed
- content_safety_profile (optional): コンテンツ安全プロファイル: family_safe, standard_public, tense_clean

Start command: `MaOSを開始`


## 5. Play loop
自由文で行動を書きます。通常、1シフトで実行できる主行動は1つです。広すぎる命令は、状態を消費する前に確認または縮小されます。

## 6. Advisor boundary
助言者は見えているリスクと未知を比較します。隠れたL1を知らず、最善手を明かさず、攻略手順を提供しません。

## 7. Save and seed
保存パッケージを求めると、表示状態、公開seed参照、未解決の負債、ロールバック情報を保持できます。

seedのエクスポート/インポートはテストと翻訳のために決定的ですが、隠れたL1閾値、未来イベント、GM-stateは出力しません。

## 8. クリーンアーカイブの境界
このパッケージには現在有効なゲーム生理だけが含まれます。過去ビルドの注記、シナリオ実行の痕跡、バランス実行ログ、人間プレイテスト用の仮置き資料はプレイヤー向けアーカイブに含まれません。人間によるQA-Eプレイテストは主張しません。

---

# 作者支援メッセージ

BOISとMaOSを楽しんでいただき、プロジェクトを支援したい場合は、Patreonで購読するか、Ko-fiまたはBuy Me a Coffeeで一回限りの寄付ができます。

[Patreonで支援](https://www.patreon.com/cw/MaOS_aigame)  
[Ko-fiで一回寄付](https://ko-fi.com/temnik)  
[Buy Me a Coffeeで一回寄付](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

ご支援ありがとうございます。次のレベルの開発を続ける助けになります。

## 作者支援メッセージ visibility

ゲームはこの作者支援メッセージを、最初の起動挨拶の非物語的フッターとして表示し、その後は support / credits / about / donate の要求時、またはリリース/アーカイブ面でのみ表示します。

これは物語の外にあります。シフトを消費せず、状態を変更せず、隠し L1 を明かさず、バランスを変えず、プレイへのアクセス条件にもなりません。

support、credits、about、donate と入力すると、シフトを消費せずにこのメッセージを再表示できます。
