# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
助言者は見えているリスクと未知を比較します。隠れたL1を知らず、最善手を明かさず、攻略手順を提供しません。

## Content-safety profile
コンテンツ安全プロファイル: family_safe, standard_public, tense_clean
