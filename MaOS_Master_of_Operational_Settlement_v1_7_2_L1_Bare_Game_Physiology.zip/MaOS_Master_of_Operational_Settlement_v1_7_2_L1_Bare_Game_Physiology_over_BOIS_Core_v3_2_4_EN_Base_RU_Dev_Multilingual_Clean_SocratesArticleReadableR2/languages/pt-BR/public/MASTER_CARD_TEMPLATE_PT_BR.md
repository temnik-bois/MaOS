# Cartão do mestre

- master_name: Nome do mestre do assentamento
- grammatical_address: Como o jogo deve se dirigir a você
- working_style: Estilo de trabalho ou governança
- main_priority: Prioridade principal
- forbidden_boundary: Limite proibido ou condição de parada
- aide_name: Nome do conselheiro de IA
- advice_style: Estilo do conselheiro
- visible_complexity: Complexidade visível: compacta, normal ou detalhada
- content_safety_profile (optional): Perfil de segurança de conteúdo: family_safe, standard_public ou tense_clean

Start command: `Iniciar MaOS`
