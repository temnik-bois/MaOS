# MaOS - Mestre do Assentamento Operacional - Quickstart

Um jogo textual BOIS sobre construir um assentamento operacional estável sob conhecimento incompleto.

## 1. What this is
MaOS é um jogo fictício em chat com IA. Você é o mestre do assentamento: decide prioridades, aceita custos, preserva pessoas e aprende com rebotes.

## 2. Safety boundary
Isto não é orientação real de sobrevivência, engenharia, medicina, direito, logística ou gestão de crises.

## 3. Start
Send: `Iniciar MaOS`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# Cartão do mestre

- master_name: Nome do mestre do assentamento
- grammatical_address: Como o jogo deve se dirigir a você
- working_style: Estilo de trabalho ou governança
- main_priority: Prioridade principal
- forbidden_boundary: Limite proibido ou condição de parada
- aide_name: Nome do conselheiro de IA
- advice_style: Estilo do conselheiro
- visible_complexity: Complexidade visível: compacta, normal ou detalhada
- content_safety_profile (optional): Perfil de segurança de conteúdo: family_safe, standard_public ou tense_clean

Start command: `Iniciar MaOS`


## 5. Play loop
Escreva ações em texto livre. Normalmente uma ação principal é executada por turno. Comandos amplos são esclarecidos ou degradados antes de gastar estado.

## 6. Advisor boundary
O conselheiro compara riscos visíveis e incógnitas. Ele não conhece o L1 oculto, não revela o melhor movimento e não fornece passo a passo.

## 7. Save and seed
Peça um pacote de salvamento para preservar estado visível, referência pública de seed, dívidas abertas e informação de rollback.

Exportação/importação de seed é determinística para testes e traduções, mas nunca exporta limites L1 ocultos, eventos futuros ou GM-state.

## 8. Limite do arquivo limpo
Este pacote contém apenas a fisiologia ativa atual do jogo. Notas de versões anteriores, rastros de cenários, registros de balanceamento e marcadores de playtest humano não fazem parte do arquivo voltado ao jogador. QA-E humano não é reivindicado.

---

# Mensagem de apoio do autor

Se você gostou de BOIS e MaOS e quer apoiar o projeto, pode assinar no Patreon ou fazer uma doação única pelo Ko-fi ou Buy Me a Coffee.

[Apoiar no Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Doação única no Ko-fi](https://ko-fi.com/temnik)  
[Doação única no Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Obrigado pelo apoio. Ele me ajuda a continuar trabalhando nos próximos níveis.

## Mensagem de apoio ao autor visibility

O jogo mostra esta mensagem de apoio ao autor como rodapé não diegético na primeira saudação de início e depois apenas por pedido support / credits / about / donate ou em superfícies de lançamento/arquivo.

Ela fica fora da ficção: não gasta turno, não muda o estado, não revela L1 oculto, não altera o balanceamento e não bloqueia o acesso ao jogo.

Você pode digitar support, credits, about ou donate para mostrar esta mensagem de novo sem gastar turno.
