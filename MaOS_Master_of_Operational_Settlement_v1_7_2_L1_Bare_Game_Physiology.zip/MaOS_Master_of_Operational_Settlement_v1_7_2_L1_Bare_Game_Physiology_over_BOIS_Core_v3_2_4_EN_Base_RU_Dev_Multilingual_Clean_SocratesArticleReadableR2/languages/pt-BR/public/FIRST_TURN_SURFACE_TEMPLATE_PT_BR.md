# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
O conselheiro compara riscos visíveis e incógnitas. Ele não conhece o L1 oculto, não revela o melhor movimento e não fornece passo a passo.

## Content-safety profile
Perfil de segurança de conteúdo: family_safe, standard_public ou tense_clean
