# Mensagem de apoio ao autor

Se você gostou de BOIS e MaOS e quer apoiar o desenvolvimento do projeto, pode assinar no Patreon ou fazer uma doação única pelo Ko-fi ou Buy Me a Coffee.

[Apoiar no Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Doação única no Ko-fi](https://ko-fi.com/temnik)  
[Doação única no Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Obrigado pelo apoio. Ele me ajuda a continuar trabalhando nos próximos níveis.
