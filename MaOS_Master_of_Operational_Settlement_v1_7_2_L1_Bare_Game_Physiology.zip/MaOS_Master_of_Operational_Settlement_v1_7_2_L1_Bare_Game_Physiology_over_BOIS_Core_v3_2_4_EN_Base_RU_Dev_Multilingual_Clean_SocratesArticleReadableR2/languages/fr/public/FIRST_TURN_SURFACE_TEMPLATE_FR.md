# First turn surface template

## Visible scene
Show the place, the current visible pressures, and 2-3 tensions. Do not expose hidden L1, GM-state, seed internals, or future events.

## Command recognition
- Player command:
- Parsed class:
- Primary action:
- Secondary actions:
- Clarification needed:

## Delta ledger
- Resources:
- Infrastructure:
- Crew/social state:
- Open debts:
- Active assets:

## Advisor note
Le conseiller compare les risques visibles et les inconnues. Il ne connaît pas le L1 caché, ne révèle pas le meilleur coup et ne fournit pas de solution pas à pas.

## Content-safety profile
Profil de sécurité du contenu: family_safe, standard_public ou tense_clean
