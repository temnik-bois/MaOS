# Carte du maître

- master_name: Nom du maître du peuplement
- grammatical_address: Comment le jeu doit s’adresser à vous
- working_style: Style de travail ou de gouvernance
- main_priority: Priorité principale
- forbidden_boundary: Limite interdite ou condition d’arrêt
- aide_name: Nom du conseiller IA
- advice_style: Style du conseiller
- visible_complexity: Complexité visible: compacte, normale ou détaillée
- content_safety_profile (optional): Profil de sécurité du contenu: family_safe, standard_public ou tense_clean

Start command: `Démarrer MaOS`
