# MaOS - Maître du Peuplement Opérationnel - Quickstart

Un jeu textuel BOIS sur la construction d’un peuplement opérationnel stable sous connaissance incomplète.

## 1. What this is
MaOS est un jeu fictionnel en chat IA. Vous êtes le maître du peuplement: vous choisissez les priorités, acceptez les coûts, préservez les personnes et apprenez des retours.

## 2. Safety boundary
Ce n’est pas un guide réel de survie, d’ingénierie, de médecine, de droit, de logistique ou de gestion de crise.

## 3. Start
Send: `Démarrer MaOS`. The game must ask for the master card before creating the first scene, seed, visible state, GM-state, or character machines.

## 4. Master card
# Carte du maître

- master_name: Nom du maître du peuplement
- grammatical_address: Comment le jeu doit s’adresser à vous
- working_style: Style de travail ou de gouvernance
- main_priority: Priorité principale
- forbidden_boundary: Limite interdite ou condition d’arrêt
- aide_name: Nom du conseiller IA
- advice_style: Style du conseiller
- visible_complexity: Complexité visible: compacte, normale ou détaillée
- content_safety_profile (optional): Profil de sécurité du contenu: family_safe, standard_public ou tense_clean

Start command: `Démarrer MaOS`


## 5. Play loop
Écrivez des actions en langage libre. Normalement, une action principale est exécutée par quart. Les ordres trop larges sont clarifiés ou dégradés avant de dépenser l’état.

## 6. Advisor boundary
Le conseiller compare les risques visibles et les inconnues. Il ne connaît pas le L1 caché, ne révèle pas le meilleur coup et ne fournit pas de solution pas à pas.

## 7. Save and seed
Demandez un paquet de sauvegarde pour conserver l’état visible, la référence publique du seed, les dettes ouvertes et les informations de retour arrière.

L’export/import du seed est déterministe pour les tests et traductions, mais n’exporte jamais les seuils L1 cachés, les événements futurs ou l’état GM.

## 8. Limite de l’archive propre
Ce paquet contient seulement la physiologie active actuelle du jeu. Les notes des versions précédentes, les traces de scénarios, les journaux d’équilibrage et les espaces réservés au playtest humain ne font pas partie de l’archive destinée aux joueurs. Aucun QA-E humain n’est revendiqué.

---

# Message de soutien de l’auteur

Si BOIS et MaOS vous ont plu et que vous souhaitez soutenir le projet, vous pouvez vous abonner sur Patreon ou faire un don ponctuel via Ko-fi ou Buy Me a Coffee.

[Soutenir sur Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Don ponctuel sur Ko-fi](https://ko-fi.com/temnik)  
[Don ponctuel sur Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Merci pour votre soutien. Il m’aide à continuer le travail sur les prochains niveaux.

## Message de soutien à l’auteur visibility

Le jeu affiche ce message de soutien à l’auteur comme pied de page non diégétique au premier accueil de démarrage, puis seulement sur demande support / credits / about / donate ou dans les surfaces de publication/archive.

Il est hors fiction : il ne dépense pas de tour, ne modifie pas l’état, ne révèle pas le L1 caché, ne change pas l’équilibrage et ne conditionne pas l’accès au jeu.

Vous pouvez écrire support, credits, about ou donate pour afficher de nouveau ce message sans dépenser de tour.
