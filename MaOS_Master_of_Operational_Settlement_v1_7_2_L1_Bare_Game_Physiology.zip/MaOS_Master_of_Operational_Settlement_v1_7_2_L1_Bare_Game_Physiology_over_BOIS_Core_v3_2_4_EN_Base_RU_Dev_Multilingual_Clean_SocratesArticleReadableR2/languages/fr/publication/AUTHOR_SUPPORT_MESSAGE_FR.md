# Message de soutien à l’auteur

Si BOIS et MaOS vous ont plu et que vous souhaitez soutenir le développement du projet, vous pouvez vous abonner sur Patreon ou faire un don ponctuel via Ko-fi ou Buy Me a Coffee.

[Soutenir sur Patreon](https://www.patreon.com/cw/MaOS_aigame)  
[Don ponctuel sur Ko-fi](https://ko-fi.com/temnik)  
[Don ponctuel sur Buy Me a Coffee](https://buymeacoffee.com/temnik)  
[About me](https://www.temnik.com)

Merci pour votre soutien. Il m’aide à continuer à travailler sur les prochains niveaux.
